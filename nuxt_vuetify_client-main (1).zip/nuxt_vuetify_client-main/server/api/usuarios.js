// server/api/usuarios.js

let usuarios = []; // State en memoria

export default defineEventHandler(async (event) => {
  const method = getMethod(event);

  if (method === 'GET') {
    return usuarios;
  }

  if (method === 'POST') {
    const nuevo = await readBody(event);
    usuarios.push(nuevo);
    return { mensaje: 'Usuario agregado', usuario: nuevo };
  }

  if (method === 'DELETE') {
    usuarios = [];
    return { mensaje: 'Usuarios eliminados' };
  }

  return { error: 'Método no permitido' };
});
