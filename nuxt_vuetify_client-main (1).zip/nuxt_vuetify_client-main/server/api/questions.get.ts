export default defineEventHandler((event) => {
  const questions = [
    {
      id: 1,
      question: "¿Qué colores componen los colores primarios aditivos?",
      answers: [
        {
          a: "Rojo, Verde y Azul",
          b: "Cian, Magenta y Amarillo",
          c: "Rojo, Amarillo y Azul",
        },
      ],
    },
    {
      id: 2,
      question: "¿Qué es la temperatura de color?",
      answers: [
        {
          a: "Una medida de cuán cálido o frío se percibe un color de luz",
          b: "La sensación térmica que produce un color al tacto",
          c: "El número de colores que contiene una imagen",
        },
      ],
    },
    {
      id: 3,
      question: "¿Cuál es un color complementario del rojo en el círculo cromático?",
      answers: [
        {
          a: "Verde",
          b: "Azul",
          c: "Amarillo",
        },
      ],
    },
    {
      id: 4,
      question: "¿Qué es la saturación en un color?",
      answers: [
        {
          a: "La intensidad o pureza de un color",
          b: "El nivel de oscuridad del color",
          c: "El brillo de una luz blanca",
        },
      ],
    },
    {
      id: 5,
      question: "¿Qué son los colores análogos?",
      answers: [
        {
          a: "Colores que están uno al lado del otro en el círculo cromático",
          b: "Colores que no combinan entre sí",
          c: "Colores opuestos en el círculo cromático",
        },
      ],
    },
  ];

  return questions;
});

function defineEventHandler(arg0: (event: any) => { id: number; question: string; answers: { a: string; b: string; c: string; }[]; }[]) {
  throw new Error("Function not implemented.");
}
