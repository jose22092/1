<template>
  <section>
    <p>This page will be displayed at the /about route.</p>
  </section>
</template>
