<template>
  <div v-if="questions.length && currentQuestion < questions.length">
    <h2>{{ questions[currentQuestion].question }}</h2>
    <ul>
      <li v-for="(value, key) in questions[currentQuestion].answers[0]" :key="key">
        <button @click="answerQuestion(key)">
          {{ key.toUpperCase() }}: {{ value }}
        </button>
      </li>
    </ul>
  </div>

  <div v-else>
    <h2>¡Quiz finalizado!</h2>
    <p>Respuestas:</p>
    <ul>
      <li v-for="(resp, idx) in answers" :key="idx">
        Pregunta {{ resp.questionId }}: opción {{ resp.answer }}
      </li>
    </ul>
  </div>
</template>

<script setup>
const { questions, currentQuestion, answers, loadQuestions, answerQuestion } = useQuiz();
await loadQuestions();
</script>