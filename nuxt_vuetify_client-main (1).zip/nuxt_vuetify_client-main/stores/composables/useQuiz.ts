import { ref } from 'vue';

export const useQuiz = () => {
  const questions = ref([]);
  const currentQuestion = ref(0);
  const answers = ref([]);

  const loadQuestions = async () => {
    const res = await fetch('/api/questions');
    questions.value = await res.json();
  };

  const answerQuestion = (answer) => {
    answers.value.push({ questionId: questions.value[currentQuestion.value].id, answer });
    currentQuestion.value++;
  };

  return {
    questions,
    currentQuestion,
    answers,
    loadQuestions,
    answerQuestion
  };
};